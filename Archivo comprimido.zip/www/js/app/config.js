'use strict';

var templates = {
	'divisas': 'views/divisas.html',
	'fila': 'views/fila.html',
	'autos': 'views/especiales/autos.html',
	'vinos': 'views/especiales/vinos.html',
	'noticia_doble': 'views/objetos/noticia_doble.html',
	'slider': 'views/objetos/slider.html'
}