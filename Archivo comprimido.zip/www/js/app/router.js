iproapp.config(['$routeProvider', '$locationProvider', 
  function($routeProvider, $locationProvider) {

    
    // $locationProvider.html5Mode({
    //         'enable': true,
    //         'requireBase': false,
    //         'rewriteLinks': false,
    //     });
    $routeProvider.
      when('/', {
        templateUrl: 'views/home.html',
        controller: 'homeController'
      }).
      when('/seccion/:seccion', {
        templateUrl: 'views/seccion.html',
        controller: 'seccionController'
      }).
      when('/home', {
        templateUrl: 'views/home.html',
        controller: 'homeController'
      }).
      when('/nota/:notaId', {
        templateUrl: 'views/noticia.html',
        controller: 'newsController'
      }).
      otherwise({
        redirectTo: '/'
      });
      console.log($locationProvider);
      $locationProvider.html5Mode(false);
}]);