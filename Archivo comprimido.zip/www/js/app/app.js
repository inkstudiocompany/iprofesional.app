'use strict';
var test = null;
var urlsource = 'http://192.168.0.29/iprofesionalApp/iprofesional.json';
var iproapp = angular.module('iprofesional', ['ngRoute', 'ngAnimate']);

iproapp.service('dataService', ['$http', 'dataFactory', '$q', 
	function($http, dataFactory, $q){
	this.load = function() {
		var defer = $q.defer();
        var promise = defer.promise;
        	$http({
				method: 'GET',
				url: urlsource,
				headers: {
	               'Content-Type': 'js/json',
	            }
			}).then(function(response){
				dataFactory.setContent(response);
				defer.resolve(true);
				test = response;
			});

        return promise;
	}
}]);

iproapp.controller('appController', 
	['$scope', '$rootScope', '$route', '$routeParams', '$location', 'dataFactory',
	function($scope, $rootScope, $route, $routeParams, $location, dataFactory){
		$scope.$route = $route;
     	$scope.$location = $location;
     	$scope.$routeParams = $routeParams;
		
		$scope.$on('$routeChangeStart', function (event, next, current) {
			$('#loader').html('').data('loadie-loaded', 0).loadie(0.1);
		});

		$scope.$on('$viewContentLoaded', function(){
  			$(window).scrollTop(0);
    $location.replace(); //clear last history route
});
		// $scope.$on('$locationChangeSuccess', function(a, b,  c, d, e){
		// 	console.log(a, b,  c, d, e);
		// 	if($rootScope.actualLocation === b) {
  //           alert('Why did you use history back?');
  //       }
		// });

		// $scope.$on('$routeChangeSuccess', function (event, next, current) {
  			
		// });

		dataFactory.setScope($scope);
		
		$location.url('/');
	}]
);

iproapp.controller('homeController', 
	['$scope', 'templateService', 'dataFactory', 'dataService',
	function($scope, templateService, dataFactory, dataService){
		dataService.load().then(function(response){
			$scope.content = dataFactory.getSeccion('home');
			$scope.divisas = dataFactory.divisas();
		});
	}]
);

iproapp.controller('seccionController', 
	['$scope', 'templateService', 'dataFactory', 'dataService', '$routeParams',
	function($scope, templateService, dataFactory, dataService, $routeParams){
		$scope = dataFactory.getScope();
		$scope.$routeParams = $routeParams;
		
		dataService.load().then(function(response){
			$scope.content = dataFactory.getSeccion($routeParams.seccion);
		});
	}]
);

iproapp.controller('newsController', ['$scope', 'templateService', '$routeParams', '$route', '$location', 
	function($scope, templateService, $routeParams, $route, $location){
		
		console.log($routeParams.notaId);

		setTimeout(function(){
     		$('#loader').loadie(1);
     	}, 1000);

	}]
)

iproapp.directive('rowcontainer', 
	['$compile', 'templateService', 'dataFactory', 
	function($compile, templateService, dataFactory){
	
	var getTemplate = function(scope) {
		if(scope.fila.type === 'noticias')
			return templates.fila;
		if(scope.fila.type === 'autos')
			return templates.autos;
		if(scope.fila.type === 'vinos')
			return templates.vinos;
		if(scope.fila.type === 'empty')
			return templates.fila;
	}

	var linker = function(scope, element, attrs) {
		templateService.get(getTemplate(scope)).then(function(response){
			element.html(response);
			$compile(element.contents())(scope);
			$('#loader').html('').data('loadie-loaded', 0).loadie(0.1);
			if (scope.$parent.$last === true) {
             	slidersStart();
             	setTimeout(function(){
             		$('#loader').loadie(1);
             	}, 1000);
            }
		});
	}

	return {
        restrict: 'E',
        link: linker,
        scope: {
            fila: '=info'
        }
    };
}]);

iproapp.directive('objeto', 
	['$compile', 'templateService', 'dataFactory', 
	function($compile, templateService, dataFactory){
	
	var getTemplate = function(scope) {
		if(scope.objeto.tipo === 'nota')
			return templates.noticia_doble;
		if(scope.objeto.tipo === 'slider')
			return templates.slider;
	}

	var linker = function(scope, element, attrs) {
		templateService.get(getTemplate(scope)).then(function(response){
			element.html(response);
			$compile(element.contents())(scope);
		});
	}

	return {
        restrict: 'E',
        link: linker,
        scope: {
            objeto: '=info'
        }
    };
}]);

iproapp.directive('notaswide', function($compile, templateService){
	var getTemplate = function() {
		return templates.notaswide;
	}

	var linker = function(scope, element, attrs) {
		templateService.get(getTemplate()).then(function(response){
			element.html(response);
			$compile(element.contents())(scope);
		});
	}

	return {
        restrict: 'E',
        link: linker,
        scope: {
            content: '=',
            template: '='
        }
    };
});

iproapp.factory('dataFactory', function($http){
	return {
			$scope: null,
			data: {

			},
			setScope: function($scope){
				this.$scope = $scope;
			},
			getScope: function(){
				return this.$scope;
			},
			setContent: function(content){
				this.data = content.data;
			},
			getContent: function(){
				return this.data;
			},
			cabezal: function(){
				return this.data.seccion;
			},
			getSeccion: function(nombre){
				var content = {};
				this.data.seccion.forEach(function(seccion){
					if (seccion.nombre == nombre) {
						content = seccion;
						return content;
					}
				});
				return content;
			},
			divisas: function(){
				return this.data.divisas;
			}
		};
});